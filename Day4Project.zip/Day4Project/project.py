#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import seaborn as sns
# 1
data = pd.read_csv("pubg.csv")
data.head()


# In[2]:


# 2
df = data.sample()
p = df.values
clm = data.columns
for i in clm:
    print(df[i])


# In[3]:


# 3
data.describe()
# All the values are equal or less than the given values in table correspondint to the column they belong

4: Average person kills 0.913400 players
 
5: 99% peoples have greater than 1 kills
 
6: Most kills ever recorded are 35.000000
# In[4]:


# All the columns of dataFrame
# 7
data.columns


# In[5]:


# 8
sns.distplot(data['matchDuration']);
# average match duration is 1375


# In[6]:


# 9
sns.distplot(data["walkDistance"]);
# maximum walk distance is nearly 4000


# In[7]:



# 10
md = data["matchDuration"].values
wd = data["walkDistance"].values
print("Match Duration",end=": ")
for i in range(len(md)):
    print(md[i],end=", ")
print()
print("Walk Distance",end=": ")
for i in range(len(wd)):
    print(wd[i],end=", ")


# In[8]:


# 11
md = data["matchDuration"].values
wd = data["walkDistance"].values
print("Match Duration       Walk Distance")
for i in range(len(md)):
    print(md[i],"               ",wd[i])


# In[9]:


# 12
sns.pairplot(data)


# In[10]:


# 13
data['matchType'].describe()
data['matchType'].unique()
data['matchType'].value_counts()


# In[33]:


# 14
import matplotlib.pyplot as plt
sns.barplot(x="matchType", y="killPoints",data=data);
plt.xticks(rotation=90);


# In[ ]:


# 15
sns.barplot(x="matchType", y="weaponsAcquired",data=data);
plt.xticks(rotation=90);


# In[34]:


# 16 
for c in data.columns[data.dtypes == object]:
    print(c,end=", ")


# In[35]:


# 17
sns.boxplot(x="matchType", y="winPlacePerc",data=data);
plt.xticks(rotation=90);


# In[32]:


# 18
sns.boxplot(x="matchType", y="matchDuration",data=data);
plt.xticks(rotation=90);


# In[31]:


# 19

sns.boxplot(x="matchType", y="matchDuration",data=data);
sns.boxplot(vert = False);
plt.xticks(rotation=90);


# In[38]:


# 20
data["KILL"] = data["headshotKills"] + data["teamKills"] + data["roadKills"]


# In[ ]:


# 21
data["winPlacePerc"] = round(data["winPlacePerc"],2)
print(data["winPlacePerc"])


# In[ ]:


# 22
s=0
for i in range(100):
    sample = data["damageDealt"].sample(50)
    s+=sample.sum()
mean = s/100
print(mean)
sample.plot.hist(bins=100);


# In[ ]:




